package com.spring.mvc.mini.pojo;

public enum StatusType {
	ongoing, hold, commited, withdraw
}