package com.spring.mvc.mini.validation;

public class ObjectClassDataValidationException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ObjectClassDataValidationException(String message) {
        super(message);
    }
}
