package command;

public class Receiver {
	public void action(){
		System.out.println("action...");
	}
	public void unAction(){
		System.out.println("unAction...");
	}
}
