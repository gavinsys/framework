package proxy;

public abstract class Subject {
	public abstract void request(); 
}
