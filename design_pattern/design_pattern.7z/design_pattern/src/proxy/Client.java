package proxy;

public class Client {
	public static void main(String[] args) {
//		Subject sub1 = new RealSubject();
//		sub1.request();
		
		Subject sub2 = new ProxySubject();
		sub2.request();
	}
}
