package memento;

public class Client {
	public static void main(String[] args) {
		Originator o = new Originator();
		Caretaker c = new Caretaker();
		o.setState("ON");
		c.saveMemento(o.createMemento());
		o.setState("OFF");
		o.restoreMemento(c.retrieveMemento());
		System.out.println(o.getState());
	}
}
