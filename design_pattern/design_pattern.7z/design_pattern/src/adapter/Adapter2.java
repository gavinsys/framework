package adapter;

public class Adapter2 {
	private Adaptee adaptee;
	public Adapter2(Adaptee adaptee){
		this.adaptee = adaptee;
	}
	public void operation1(){
		this.adaptee.operation1();
	}
	public void operation2(){
		System.out.println("operation2...");
	}
}
