package adapter;

public class Adaptee {
	public void operation1(){
		System.out.println("operation1...");
	}
}
