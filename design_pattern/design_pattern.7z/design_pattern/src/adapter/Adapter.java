package adapter;

public class Adapter extends Adaptee implements Target{
	
	public void operation2() {
		System.out.println("operation2...");
	}

}
