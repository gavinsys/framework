package adapter;

public interface Target {
	public void operation1();
	public void operation2();
}
