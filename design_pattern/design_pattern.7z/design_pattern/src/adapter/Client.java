package adapter;

public class Client {
	public static void main(String[] args) {
		Adaptee ad1 = new Adapter();
		Adapter ad2 = new Adapter();
		ad1.operation1();
		ad2.operation2();
	}
}
