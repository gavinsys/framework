package prototype;

public interface Prototype {
	 public Object cloneMe() throws CloneNotSupportedException;
}
