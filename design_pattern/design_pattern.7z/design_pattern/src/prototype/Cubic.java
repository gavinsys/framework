package prototype;


public class Cubic implements Prototype, Cloneable {
	double length,width,height;
	public Cubic(double a, double b, double c){
		length = a;
		width = b;
		height = c;
	}
	@Override
	public Object cloneMe() throws CloneNotSupportedException {
		Cubic object = (Cubic)clone();
		return object;
	}

}
