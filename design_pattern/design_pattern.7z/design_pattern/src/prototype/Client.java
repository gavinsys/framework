package prototype;

public class Client {
	public static void main(String[] args) {  
        Cubic cubic = new Cubic(12, 20, 66);  
        System.out.println("cubic�ĳ������͸ߣ�");  
        System.out.println(cubic.length + "," + cubic.width + ","  
                    + cubic.height);  
        try {  
              Cubic cubicopy = (Cubic) cubic.cloneMe();  
              System.out.println("cubicopy�ĳ������͸ߣ�");  
              System.out.println(cubicopy.length + "," + cubicopy.width + ","  
                          + cubicopy.height);  
        } catch (Exception e) {  
        }  
        Goat goat = new Goat();  
        goat.setColor(new StringBuffer("��ɫ��ɽ��"));  
        System.out.println("goat ��" + goat.getColor());  
        try {  
              Goat goatCopyGoat = (Goat) goat.cloneMe();  
              System.out.println("goatCopy��" + goatCopyGoat.getColor());  
              System.out.println("goatCopy���Լ�����ɫ�ı�ɺ�ɫ");  
              goatCopyGoat.setColor(new StringBuffer("��ɫ��ɽ��"));  
              System.out.println("goat��Ȼ��" + goat.getColor());  
              System.out.println("goatCopy��" + goatCopyGoat.getColor());  
        } catch (Exception e) {  
              // TODO: handle exception  
        }  
  }  
}
