package composite;

import java.util.Enumeration;
import java.util.Vector;

public class Composite implements Component {
	private Vector vector = new Vector();
	
	@Override
	public void operation() {
		Enumeration enumeration = components();  
        while (enumeration.hasMoreElements()){  
            ((Component)(enumeration.nextElement())).operation();  
        }  
	}
	
	public void add(Component component){
		vector.add(component);
	}
	
	public void remove(Component component){
		vector.remove(component);
	}

	public Enumeration components(){
		return vector.elements();
	}
}
