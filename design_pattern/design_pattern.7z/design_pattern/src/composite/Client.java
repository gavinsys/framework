package composite;

public class Client {
	public static void main(String[] args) {
//		Leaf l = new Leaf();
//		l.operation();
  
        //�����֦  
        Composite root = new Composite();  
        //�����֦  
        Composite c1 = new Composite();  
        Leaf l = new Leaf();
        c1.add(l);
        c1.add(new Leaf());
        c1.add(new Leaf());
        c1.remove(l);
        root.add(c1);
        root.operation();
        
	}
}
