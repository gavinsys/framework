package composite;

public interface Component {
	public void operation();
}
