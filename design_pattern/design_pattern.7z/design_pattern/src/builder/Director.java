package builder;

public class Director {
	private AbstractBuilder builder1 = new ConcreteBuilderA();
	private AbstractBuilder builder2 = new ConcreteBuilderB();
	public AbstractProductionLine getProductA(){
		builder1.buildCarParts();
		return builder1.buildCar();
	}
	
	public AbstractProductionLine getProductB(){
		builder2.buildCarParts();
		return builder2.buildCar();
	}
}
