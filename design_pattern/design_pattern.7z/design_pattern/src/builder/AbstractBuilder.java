package builder;

public abstract class AbstractBuilder {
	public abstract void buildCarParts();
	public abstract AbstractProductionLine buildCar();
}
