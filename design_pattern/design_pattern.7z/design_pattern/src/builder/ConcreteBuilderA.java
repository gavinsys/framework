package builder;

public class ConcreteBuilderA extends AbstractBuilder {
	private AbstractProductionLine line = new ConcreteProductLineA();
	@Override
	public void buildCarParts() {
		line.createEngine();
		line.createSecuritySystem();
		line.createCarBody();
	}

	@Override
	public AbstractProductionLine buildCar() {
		return line;
	}

}
