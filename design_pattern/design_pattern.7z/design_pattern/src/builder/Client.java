package builder;

public class Client {
	public static void main(String[] args) {
		Director d = new Director();
		AbstractProductionLine buidler1 = d.getProductA();
		System.out.println("==============");
		AbstractProductionLine buidler2 = d.getProductB();
		
	}
}
