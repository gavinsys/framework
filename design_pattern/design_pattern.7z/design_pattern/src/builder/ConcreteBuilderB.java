package builder;

public class ConcreteBuilderB extends AbstractBuilder {
	private AbstractProductionLine line = new ConcreteProductLineB();
	@Override
	public void buildCarParts() {
		line.createEngine();
		line.createSecuritySystem();
		line.createCarBody();
	}

	@Override
	public AbstractProductionLine buildCar() {
		return line;
	}

}
