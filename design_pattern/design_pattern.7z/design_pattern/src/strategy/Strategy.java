package strategy;

public interface Strategy {
	public int calculate(int a, int b);
}
