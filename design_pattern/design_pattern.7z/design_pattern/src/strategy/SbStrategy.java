package strategy;

public class SbStrategy implements Strategy{

	@Override
	public int calculate(int a, int b) {
		return a - b;
	}

}
