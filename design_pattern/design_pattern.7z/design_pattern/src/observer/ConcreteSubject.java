package observer;

public class ConcreteSubject extends Subject {
	public void change(String newState){
		this.nodifyObservers(newState);
	}
}
