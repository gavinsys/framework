package observer;

import java.util.Observable;

public class Watched extends Observable{
	private String state = "0";

	public String getState() {
		return state;
	}

	public void setState(String state) {
		if(!this.state.equals(state)){
			this.state = state;
			setChanged();
		}
		notifyObservers();
	}
	
}
