package observer;

import java.util.Observer;

public class Client {
	public static void main(String[] args) {
//		ConcreteSubject subject = new ConcreteSubject();
//		Observer observer1 = new ConcreteObserver();
//		Observer observer2 = new ConcreteObserver();
//		subject.attach(observer1);
//		subject.attach(observer2);
//		subject.change("new State...");
		
		Watched watched = new Watched();
		Observer watcher1 = new Watcher(watched);
		Observer watcher2 = new Watcher(watched);
		watched.setState("1");
	}
}
