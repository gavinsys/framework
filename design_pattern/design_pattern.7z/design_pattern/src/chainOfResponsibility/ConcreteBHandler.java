package chainOfResponsibility;

public class ConcreteBHandler extends Handler {

	@Override
	public void handleRequest() {
		if(getHandler()!=null){
			getHandler().handleRequest();
		}
		System.out.println("ConcreteBHandler...");
	}

}
