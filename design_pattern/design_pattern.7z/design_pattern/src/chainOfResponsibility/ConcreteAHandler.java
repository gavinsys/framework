package chainOfResponsibility;

public class ConcreteAHandler extends Handler {

	@Override
	public void handleRequest() {
		if(getHandler()!=null){
			getHandler().handleRequest();
		}
		System.out.println("ConcreteAHandler...");
	}

}
