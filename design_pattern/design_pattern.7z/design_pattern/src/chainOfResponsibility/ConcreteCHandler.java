package chainOfResponsibility;

public class ConcreteCHandler extends Handler {

	@Override
	public void handleRequest() {
		if(getHandler()!=null){
			getHandler().handleRequest();
		}
		System.out.println("ConcreteCHandler...");
	}

}
