package chainOfResponsibility;

public class Client {
	public static void main(String[] args) {
		Handler handler1 = new ConcreteAHandler();
		Handler handler2 = new ConcreteBHandler();
		Handler handler3 = new ConcreteCHandler();
		handler1.setHandler(handler2);
		handler2.setHandler(handler3);
		handler1.handleRequest();
	}
}
