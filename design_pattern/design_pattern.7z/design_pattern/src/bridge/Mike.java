package bridge;

public class Mike extends Clothing {

	@Override
	public void dressCloth(Person person) {
		System.out.println(person.getType()+" Dress Cloth B.");
	}

}
