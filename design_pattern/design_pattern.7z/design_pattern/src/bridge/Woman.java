package bridge;

public class Woman extends Person {
	public Woman(){
		setType("Woman");
	}
	@Override
	public void dress() {
		getClothing().dressCloth(this);

	}

}
