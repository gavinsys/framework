package bridge;

public class Jacket extends Clothing {

	@Override
	public void dressCloth(Person person) {
		System.out.println(person.getType()+" Dress Cloth A.");
	}

}
