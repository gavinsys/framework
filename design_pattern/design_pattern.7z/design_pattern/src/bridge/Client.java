package bridge;

public class Client {
	public static void main(String[] args) {
		Person man = new Man();
		Person woman = new Woman();
		
		Clothing jacket = new Jacket();
		Clothing mike = new Mike();
		jacket.dressCloth(man);
		mike.dressCloth(woman);
	}
}
