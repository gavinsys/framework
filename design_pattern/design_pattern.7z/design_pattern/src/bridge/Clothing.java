package bridge;

public abstract class Clothing {
	public abstract void dressCloth(Person person);
}
