
package decorator;

public class ConcreteBDecorator extends Decorator {

	public ConcreteBDecorator(Component component) {
		super(component);
	}
	
	public void doSomething(){
		super.doSomething();
	}

}
