package decorator;

public interface Component {
	public void doSomething();
}
