package decorator;

public class Client {
	public static void main(String[] args) {
		Component component = new ConcreteComponent();
		Component decorator = new Decorator(component);
		Component decoratorA =  new ConcreteADecorator(decorator);
		Component decoratorB =  new ConcreteBDecorator(decorator);
		decoratorA.doSomething();
		decoratorB.doSomething();
	}
}

