package decorator;

public class ConcreteComponent implements Component {

	@Override
	public void doSomething() {
		System.out.println("doSomething...");
	}

}
