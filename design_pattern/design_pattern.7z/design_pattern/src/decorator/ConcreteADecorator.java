
package decorator;

public class ConcreteADecorator extends Decorator {

	public ConcreteADecorator(Component component) {
		super(component);
	}
	
	public void doSomething(){
		super.doSomething();
	}

}
