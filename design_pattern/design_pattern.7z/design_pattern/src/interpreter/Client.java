package interpreter;

public class Client {
	public static void main(String[] args) {
		Context context = new Context();
		Variable v = new Variable("true");
		Constant c = new Constant(true);
		context.assign(v, false);
		System.out.println(v.interpret(context));
		Expression ex = new Add(v, c);
		System.out.println(ex.equals(c));
	}
}
