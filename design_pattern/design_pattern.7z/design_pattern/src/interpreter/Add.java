package interpreter;

public class Add extends Expression {
	public Expression left,right;
	public Add(Expression left, Expression right){
		this.left = left;
		this.right = right;
	}
	@Override
	public boolean interpret(Context context) {
		return left.interpret(context) && right.interpret(context);
	}

	@Override
	public boolean equals(Object o) {
		if(o != null && o instanceof Add){
			return this.left.equals(((Add)o).left) && this.right.equals(((Add)o).right);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public String toString() {
		return left.toString() + " AND " + this.right.toString();
	}

}
