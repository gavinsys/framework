package interpreter;

public class Variable extends Expression{
	private String value;
	public Variable(String value){
		this.value = value;
	}
	@Override
	public boolean interpret(Context context) {
		return context.lookup(this);
	}

	@Override
	public boolean equals(Object o) {
		if(o != null && o instanceof Variable){
			return this.value ==((Variable)o).value;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public String toString() {
		return value;
	}

}
