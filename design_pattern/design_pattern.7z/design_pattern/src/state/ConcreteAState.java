package state;

public class ConcreteAState implements State{

	@Override
	public void handle(String state) {
		System.out.println("ConcreteAState :"+ state);
	}

}
