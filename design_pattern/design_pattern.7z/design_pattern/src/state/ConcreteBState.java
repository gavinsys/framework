package state;

public class ConcreteBState implements State{

	@Override
	public void handle(String state) {
		System.out.println("ConcreteBState :"+ state);
	}

}
