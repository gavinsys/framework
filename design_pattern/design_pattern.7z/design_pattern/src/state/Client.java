package state;

public class Client {
	public static void main(String[] args) {
		State stateA = new ConcreteAState();
		State stateB = new ConcreteBState();
		Context context = new Context();
		context.setState(stateA);
		context.request("0");
		context.setState(stateB);
		context.request("1");
	}
}
