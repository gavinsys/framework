package template;

public class ConcreteTemplate extends AbstractTemplate {

	@Override
	protected void abstractMethod() {
		System.out.println("abstractMethod...");
	}

	@Override
	protected void hookMethod() {
		System.out.println("hookMethod...");
	}
	
}
