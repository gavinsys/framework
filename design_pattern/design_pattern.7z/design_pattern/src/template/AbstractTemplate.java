package template;

public abstract class AbstractTemplate {
	public void templateMethod(){
		abstractMethod();
        hookMethod();
        concreteMethod();
	}
	protected abstract void abstractMethod();
	protected abstract void hookMethod();
	protected final void concreteMethod(){
		System.out.println("concreteMethod...");
	}
}
