package facade;

public class Client {
	public static void main(String[] args) {
		Waiter waiter = new Waiter();
		waiter.helpCustomer("egg");
	}
}
