package facade;

public class MenuDepartment {
	public void provideMenu(String menu){
		System.out.println("Menu: "+ menu);
	}
}
