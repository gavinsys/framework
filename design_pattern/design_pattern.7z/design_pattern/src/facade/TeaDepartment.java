package facade;

public class TeaDepartment {
	public void provideTea(){
		System.out.println("Tea: soft Tea");
	}
}
