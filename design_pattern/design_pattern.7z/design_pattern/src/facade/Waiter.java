package facade;

public class Waiter {
	BoardDepartment board = new BoardDepartment();
	MenuDepartment menus = new MenuDepartment();
	TeaDepartment tea = new TeaDepartment();
	
	public void helpCustomer(String menu){
		board.providBoard();
		tea.provideTea();
		menus.provideMenu(menu);
	}
}
