package facade;

import java.util.Random;

public class BoardDepartment {
	public void providBoard(){
		System.out.println("ID: "+ new Random().nextInt(100));
	}
}
