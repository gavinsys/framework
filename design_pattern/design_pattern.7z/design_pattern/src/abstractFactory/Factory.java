package abstractFactory;

public abstract class Factory {
	abstract Product getProductA();
	abstract Product getProductB();
}
