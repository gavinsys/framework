package abstractFactory;

public class ConcreteFactory extends Factory {

	@Override
	Product getProductA() {
		return new ProductA();
	}

	@Override
	Product getProductB() {
		return new ProductB();
	}

}
