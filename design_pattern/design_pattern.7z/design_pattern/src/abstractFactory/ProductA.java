package abstractFactory;

import abstractFactory.Product;

public class ProductA implements Product {

	@Override
	public void method() {
		System.out.println("ProductA...");
	}

}
