package abstractFactory;

public interface Product {
	public void method();
}
