package abstractFactory;

import abstractFactory.Product;

public class ProductB implements Product {

	@Override
	public void method() {
		System.out.println("ProductB...");
	}

}
