package dynamicProxy;

public interface Subject {
	public void request();
}
