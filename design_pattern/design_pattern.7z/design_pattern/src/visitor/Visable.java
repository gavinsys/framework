package visitor;

public interface Visable {
	public void accept(PersonVisitor visitor);
}
