package visitor;

import java.util.Iterator;
import java.util.List;

public class Visitor implements PersonVisitor {

	@Override
	public void visitor(Hand hand) {
		System.out.println("hand...");
	}

	@Override
	public void visitor(Leg leg) {
		System.out.println("leg...");
	}

	public void visitorAll(List list){
		Iterator it = list.iterator();
		while(it.hasNext()){
			Visable vi = (Visable) it.next();
			vi.accept(this);
		}
	}
}
