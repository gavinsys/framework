package visitor;

public interface PersonVisitor {
	public void visitor(Hand hand);
	public void visitor(Leg leg);
}
