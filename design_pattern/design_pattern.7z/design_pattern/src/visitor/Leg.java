package visitor;

public class Leg implements Visable {

	@Override
	public void accept(PersonVisitor visitor) {
		visitor.visitor(this);
	}

}
