package visitor;

import java.util.ArrayList;
import java.util.List;

public class Client {
	public static void main(String[] args) {
		Hand hand = new Hand();
		Leg leg = new Leg();
		Visitor vi = new Visitor();
		hand.accept(vi);
		leg.accept(vi);
		List list = new ArrayList();
		list.add(hand);
		list.add(leg);
		vi.visitorAll(list);
	}
}
