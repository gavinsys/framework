package factory;

public interface Product {

}
