package factory;

public class ConcreteBCreator implements Creator {
	@Override
	public Product factory() {
		return new ConcreteBProduct();
	}
}
