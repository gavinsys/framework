package factory;

public class ConcreteBProduct implements Product {
	public ConcreteBProduct(){
		System.out.println("ConcreteBProduct...");
	}
}
