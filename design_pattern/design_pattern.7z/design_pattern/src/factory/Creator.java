package factory;

public interface Creator {
	public Product factory();
}
