package factory;

public class ConcreteACreator implements Creator {
	@Override
	public Product factory() {
		return new ConcreteAProduct();
	}
}
