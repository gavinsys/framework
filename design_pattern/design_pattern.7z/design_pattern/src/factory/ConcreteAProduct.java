package factory;

public class ConcreteAProduct implements Product {
	public ConcreteAProduct(){
		System.out.println("ConcreteAProduct...");
	}
}
