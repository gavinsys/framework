package singleton;



public class Singleton {
	private static Singleton singleton = new Singleton();
	private Singleton(){}
	public static Singleton getInstance(){
		return singleton;
//		if(singleton == null){
//			synchronized (Singleton.class) {
//				if(singleton == null){
//					try {
//						Thread.sleep(new Random().nextInt(1000));
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//					singleton = new Singleton();
//				}
//			}
//		}
//		return singleton;
		
//		if(singleton == null){
//			synchronized (Singleton.class) {
//				if(singleton == null){
//					try {
//						Thread.sleep(new Random().nextInt(1000));
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//					singleton = new Singleton();
//				}
//			}
//		}
//		return singleton;
	}
	
}
