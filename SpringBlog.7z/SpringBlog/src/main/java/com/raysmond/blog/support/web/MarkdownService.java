package com.raysmond.blog.support.web;

/**
 * @author Raysmond<i@raysmond.com>
 */
public interface MarkdownService {
    public String renderToHtml(String content);
}
