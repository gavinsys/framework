package com.raysmond.blog.support.web;

/**
 * @author Raysmond<i@raysmond.com>
 */
public interface SyntaxHighlightService {
    public String highlight(String content);
}
